from pymongo import MongoClient
from bson.objectid import ObjectId
import urllib.parse

#constructor - authenticates using username, password, host and port number
#switches into animals collection in AAC database
class AnimalShelter(object):
    def __init__(self):
        USER = 'aacuser'
        PASS = 'detroit'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31105
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

       
    #create - adds a record in the dataset
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)
            if insert != 0:
                return True
            else:
                return False
        else:
            raise Exception("Request invalid, doc is empty")
    
    #read - reads information from a record in the dataset
    def read(self, criteria = None):
        if criteria is not None:
            _data = self.database.animals.find(criteria, {'_id' : 0})                   
        else:
            _data = self.database.animals.find({}, {'_id' : 0})                 
        return _data
