
from animal_shelter import AnimalShelter
animals = AnimalShelter()

#creates a 1 year old pitbull named Spot
animals.create({
          'age_upon_outcome': "1 year",
          'animal_id': 'GA30311', 
          'animal_type': 'Dog', 
          'breed': 'Pitbull', 
          'color': 'White', 
          'date_of_birth': '2024-01-01', 
          'datetime': '2024-01-01 12:00:00', 
          'monthyear': '2024-01-24T12:00:00', 
          'name': 'Spot', 
          'outcome_subtype': '', 
          'outcome_type': 'Rescue', 
          'sex_upon_outcome': 'Intact Male', 
          'location_lat': 69.69, 
          'location_long': -96.96, 
          'age_upon_outcome_in_weeks': 52.14
          })
 
i = animals.read({"name": "Spot", 'age_upon_outcome': '1 year'})
for docs in i:
    print(docs)

#changes Spot's outcome type to "purebred"
updateAnimal = animals.update({"name": "Spot"}, {"outcome_type": "Purebred"})
print(updateAnimal)

i = animals.read({"name": "Spot"})
for animal in i:
    print(animal)


#removes Spot from the dataset, let's assume he's been adopted
deleteAnimal = animals.delete({"name": "Spot"})
print(deleteAnimal)

i = animals.read({"name": "Spot"})
for animal in i:
    print(animal)